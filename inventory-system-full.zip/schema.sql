CREATE DATABASE IF NOT EXISTS inventory_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE inventory_db;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  model VARCHAR(100) NOT NULL,
  category VARCHAR(100) DEFAULT 'General',
  quantity INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id VARCHAR(100) NOT NULL,
  date_text VARCHAR(100) DEFAULT '',
  customer VARCHAR(200) DEFAULT '',
  status VARCHAR(50) DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) DEFAULT '',
  email VARCHAR(200) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- sample products
INSERT INTO products (name, model, category, quantity) VALUES
('Laptop', 'LAP-5423', 'Laptop', 45),
('Smartphone', 'PHN-3452', 'Phone', 50),
('Headphones', 'PKE-345', 'Accessories', 42),
('Earbuds', 'OKZ-AKG', 'Accessories', 8),
('Mouse', 'VXE-R1', 'Accessories', 34),
('Keyboard', 'AULA-ASFD', 'Accessories', 28),
('Tablet', 'TPC-ASFA', 'Tablet', 15),
('GPU', 'AMD-RADEON', 'GPU', 32);

-- sample order
INSERT INTO orders (order_id, date_text, customer, status) VALUES
('ORD-100', '2025-01-01', 'Sample Customer', 'Pending');