// app.js - frontend logic (login, products, orders)
const API = '/api';
let token = localStorage.getItem('AUTH_TOKEN') || null;
const pages = document.querySelectorAll('.page');
const navs = document.querySelectorAll('.nav');
const productBody = document.getElementById('productBody');
const orderBody = document.getElementById('orderBody');
const statTotal = document.getElementById('statTotal');
const statLow = document.getElementById('statLow');
const modal = document.getElementById('modal');
const orderModal = document.getElementById('orderModal');
const authModal = document.getElementById('authModal');
const btnLogout = document.getElementById('btnLogout');
const who = document.getElementById('who');

function setUserUI(user) {
  if (user) {
    who.textContent = user.name || user.email;
    btnLogout.style.display = 'inline-block';
  } else {
    who.textContent = 'Not signed in';
    btnLogout.style.display = 'none';
  }
}

if (!token) {
  setTimeout(()=> authModal.classList.remove('hidden'), 300);
} else {
  loadProducts(); loadStats(); loadOrders();
  setUserUI(parseJwt(token));
}

navs.forEach(n => n.addEventListener('click', () => {
  navs.forEach(x => x.classList.remove('active'));
  n.classList.add('active');
  const page = n.dataset.page;
  pages.forEach(p => p.classList.add('hidden'));
  document.getElementById(page).classList.remove('hidden');
}));

function authHeaders() {
  return token ? { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
}

function parseJwt(t) {
  try {
    const payload = JSON.parse(atob(t.split('.')[1]));
    return payload;
  } catch { return null; }
}

// PRODUCTS
async function loadProducts(){
  try {
    const res = await fetch(API + '/products');
    const products = await res.json();
    renderProducts(products);
  } catch (e) {
    console.error(e);
  }
}

function renderProducts(products){
  if (!products.length) {
    productBody.innerHTML = '<tr><td colspan="6">No products</td></tr>'; return;
  }
  productBody.innerHTML = products.map(p => {
    const statusClass = p.quantity === 0 ? 's-out' : (p.quantity < 20 ? 's-low' : 's-in');
    const statusText = p.quantity === 0 ? 'Out' : (p.quantity < 20 ? 'Low' : 'In');
    return `<tr>
      <td>${escapeHtml(p.name)}</td>
      <td>${escapeHtml(p.model)}</td>
      <td>${escapeHtml(p.category)}</td>
      <td>${p.quantity}</td>
      <td><span class="status ${statusClass}">${statusText}</span></td>
      <td>
        <button class="btn" onclick="openEdit(${p.id})">Edit</button>
        <button class="btn" onclick="deleteProduct(${p.id})">Delete</button>
      </td>
    </tr>`;
  }).join('');
}

// ORDERS
async function loadOrders(){
  if (!token) { orderBody.innerHTML = '<tr><td colspan="5">Login to view orders</td></tr>'; return; }
  try {
    const res = await fetch(API + '/orders', { headers: authHeaders() });
    if (!res.ok) { orderBody.innerHTML = '<tr><td colspan="5">Failed to load orders</td></tr>'; return; }
    const orders = await res.json();
    orderBody.innerHTML = orders.map(o => `<tr>
      <td>${escapeHtml(o.order_id)}</td>
      <td>${escapeHtml(o.date_text)}</td>
      <td>${escapeHtml(o.customer)}</td>
      <td>${escapeHtml(o.status)}</td>
      <td>
        <button class="btn" onclick="openEditOrder(${o.id})">Edit</button>
        <button class="btn" onclick="deleteOrder(${o.id})">Delete</button>
      </td>
    </tr>`).join('');
  } catch (e) {
    console.error(e);
  }
}

// STATS
async function loadStats(){
  if (!token) return;
  try {
    const res = await fetch(API + '/stats', { headers: authHeaders() });
    if (!res.ok) return;
    const s = await res.json();
    statTotal.textContent = s.total ?? 0;
    statLow.textContent = s.lowStockCount ?? 0;
  } catch (e) { console.error(e); }
}

// modal handlers - products
const openAdd = document.getElementById('openAdd');
const save = document.getElementById('save');
const cancel = document.getElementById('cancel');
const pname = document.getElementById('pname');
const pmodel = document.getElementById('pmodel');
const pcat = document.getElementById('pcat');
const pqty = document.getElementById('pqty');
let editingId = null;

openAdd && openAdd.addEventListener('click', () => {
  editingId = null; document.getElementById('modalTitle').textContent = 'Add Product';
  pname.value=''; pmodel.value=''; pcat.value='Laptop'; pqty.value=0; modal.classList.remove('hidden');
});
cancel && cancel.addEventListener('click', ()=> modal.classList.add('hidden'));

save && save.addEventListener('click', async () => {
  if (!token) return alert('You must login to add products');
  const body = { name: pname.value.trim(), model: pmodel.value.trim(), category: pcat.value, quantity: Number(pqty.value) || 0 };
  if (!body.name || !body.model) return alert('Name and model required');
  try {
    const url = editingId ? API + '/products/' + editingId : API + '/products';
    const method = editingId ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers: authHeaders(), body: JSON.stringify(body) });
    if (!res.ok) return alert('Save failed');
    modal.classList.add('hidden'); loadProducts(); loadStats();
  } catch (e) { console.error(e); alert('Save failed'); }
});

window.openEdit = async function(id){
  if (!token) return alert('Login to edit');
  try {
    const res = await fetch(API + '/products/' + id, { headers: authHeaders() });
    if (!res.ok) return alert('Not found');
    const p = await res.json();
    editingId = id; document.getElementById('modalTitle').textContent = 'Edit Product';
    pname.value = p.name; pmodel.value = p.model; pcat.value = p.category; pqty.value = p.quantity;
    modal.classList.remove('hidden');
  } catch (e) { console.error(e); }
};
window.deleteProduct = async function(id){
  if (!token) return alert('Login to delete');
  if (!confirm('Delete product?')) return;
  try {
    await fetch(API + '/products/' + id, { method: 'DELETE', headers: authHeaders() });
    loadProducts(); loadStats();
  } catch (e) { console.error(e); alert('Delete failed'); }
};

// Orders modal & actions
const openOrder = document.getElementById('openOrder');
const saveOrder = document.getElementById('saveOrder');
const cancelOrder = document.getElementById('cancelOrder');
const oid = document.getElementById('oid');
const odate = document.getElementById('odate');
const ocust = document.getElementById('ocust');
const ostatus = document.getElementById('ostatus');
let editingOrder = null;

openOrder && openOrder.addEventListener('click', ()=>{
  editingOrder = null; document.getElementById('orderTitle').textContent='Add Order';
  oid.value='ORD-'+Date.now(); odate.value = new Date().toISOString().slice(0,10); ocust.value=''; ostatus.value='Pending';
  orderModal.classList.remove('hidden');
});
cancelOrder && cancelOrder.addEventListener('click', ()=> orderModal.classList.add('hidden'));
saveOrder && saveOrder.addEventListener('click', async ()=>{
  if (!token) return alert('Login to add orders');
  const body = { orderId: oid.value.trim(), date: odate.value.trim(), customer: ocust.value.trim(), status: ostatus.value };
  try {
    const url = editingOrder ? API + '/orders/' + editingOrder : API + '/orders';
    const method = editingOrder ? 'PUT' : 'POST';
    const res = await fetch(url, { method, headers: authHeaders(), body: JSON.stringify(body) });
    if (!res.ok) return alert('Save failed');
    orderModal.classList.add('hidden'); loadOrders();
  } catch (e) { console.error(e); alert('Save failed'); }
});

window.openEditOrder = async function(id){
  try {
    const res = await fetch(API + '/orders/' + id, { headers: authHeaders() });
    if (!res.ok) return alert('Not found');
    const o = await res.json();
    editingOrder = id; document.getElementById('orderTitle').textContent='Edit Order';
    oid.value = o.order_id; odate.value = o.date_text; ocust.value = o.customer; ostatus.value = o.status;
    orderModal.classList.remove('hidden');
  } catch(e){ console.error(e); }
};
window.deleteOrder = async function(id){
  if (!confirm('Delete order?')) return;
  try {
    await fetch(API + '/orders/' + id, { method: 'DELETE', headers: authHeaders() });
    loadOrders();
  } catch(e){ console.error(e); alert('Delete failed'); }
};

// Auth: login/register
const btnLogin = document.getElementById('btnLogin');
const btnRegister = document.getElementById('btnRegister');
const email = document.getElementById('email');
const password = document.getElementById('password');

btnLogin && btnLogin.addEventListener('click', async ()=>{
  const body = { email: email.value.trim(), password: password.value.trim() };
  if (!body.email || !body.password) return alert('Fill both fields');
  try {
    const res = await fetch(API + '/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    if (!res.ok) {
      const e = await res.json(); return alert(e.error || 'Login failed');
    }
    const data = await res.json();
    token = data.token; localStorage.setItem('AUTH_TOKEN', token);
    setUserUI({ name: data.user.name, email: data.user.email });
    authModal.classList.add('hidden');
    loadProducts(); loadStats(); loadOrders();
  } catch (e) { console.error(e); alert('Login failed'); }
});

btnRegister && btnRegister.addEventListener('click', async ()=>{
  const body = { email: email.value.trim(), password: password.value.trim(), name: '' };
  if (!body.email || !body.password) return alert('Fill both fields');
  try {
    const res = await fetch(API + '/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    if (!res.ok) { const e = await res.json(); return alert(e.error || 'Register failed'); }
    const data = await res.json();
    token = data.token; localStorage.setItem('AUTH_TOKEN', token);
    setUserUI({ name: data.user.name || data.user.email, email: data.user.email });
    authModal.classList.add('hidden');
    loadProducts(); loadStats(); loadOrders();
  } catch (e) { console.error(e); alert('Register failed'); }
});

btnLogout && btnLogout.addEventListener('click', ()=>{
  token = null; localStorage.removeItem('AUTH_TOKEN'); setUserUI(null); authModal.classList.remove('hidden');
});

document.getElementById('refresh') && document.getElementById('refresh').addEventListener('click', ()=> { loadProducts(); loadStats(); loadOrders(); });

loadProducts();
loadOrders();
if (token) loadStats();

function escapeHtml(text){
  if (!text) return '';
  return text.replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
}